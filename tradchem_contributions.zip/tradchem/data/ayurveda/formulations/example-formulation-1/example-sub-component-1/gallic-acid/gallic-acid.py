﻿#!/usr/bin/env python3
"""
Trad-Chem-LLM submission record for Gallic acid.
Canonical chemical definition and ranked target proteins.
"""
import sqlite3
import sys
from pathlib import Path

# import_data.py lives in <repo>/contributions/
sys.path.insert(0, str(Path(__file__).resolve().parents[7] / "contributions"))
try:
    from import_data import import_record, DB_DEFAULT
except ImportError:
    pass

# ------------------------------------------------------------------ the chemical
CHEMICAL = {'medicine': 'Example Medicine A', 'system': 'Ayurveda', 'plant': 'Curcuma longa', 'plant_type': 'herb', 'part_used': 'rhizome', 'family': 'Zingiberaceae', 'common_name': 'Turmeric', 'chemical_name': 'Gallic acid', 'smiles': 'O=C(O)c1cc(O)c(O)c(O)c1', 'pubchem_cid': '370', 'diseases': ['colorectal cancer']}


# ------------------------------------------------------------------ one protein slot
def slot(uniprot_id="", protein_name="", protein_acronym="", species="", taxon_id="",
         cell_types=(), best_structure="", other_structures=(), go_terms=(),
         protein_diseases=(), method="", score="", source_ref=""):
    """best_structure / other_structures look like  PDB:5IKR  |  AlphaFold:AF-P35354-F1  |  SWISS-MODEL:xxxx
    go_terms look like  "GO:0006954 inflammatory response"
    method: literature / SwissTargetPrediction / NetInfer / TrackMyPDB / docking / assay
    score: affinity or probability"""
    return dict(uniprot_id=uniprot_id, protein_name=protein_name, protein_acronym=protein_acronym,
                species=species, taxon_id=taxon_id, cell_types=list(cell_types),
                best_structure=best_structure, other_structures=list(other_structures),
                go_terms=list(go_terms), protein_diseases=list(protein_diseases),
                method=method, score=score, source_ref=source_ref)


# ------------------------------------------------------------------ top 10 proteins, best first
TARGETS = [
    slot(uniprot_id='P16109', protein_name='', protein_acronym='', species='Homo sapiens', taxon_id=9606, cell_types=[], best_structure='AlphaFold:AF-P16109-F1', other_structures=[], go_terms=[], protein_diseases=[], method='assay', score=19100.0, source_ref='ChEMBL activity 1821493'),
    slot(uniprot_id='P14151', protein_name='L-selectin', protein_acronym='SELL', species='Homo sapiens', taxon_id=9606, cell_types=[], best_structure='PDB:5VC1', other_structures=['PDB:3CFW', 'PDB:2LGF', 'AlphaFold:AF-P14151-F1'], go_terms=['GO:0009897 external side of plasma membrane', 'GO:0005886 plasma membrane', 'GO:0030667 secretory granule membrane', 'GO:0005509 calcium ion binding', 'GO:0030246 carbohydrate binding'], protein_diseases=[], method='assay', score=27600.0, source_ref='ChEMBL activity 1819029'),
    slot(uniprot_id='P54300', protein_name='Autoinducer 2-binding periplasmic protein LuxP', protein_acronym='luxP', species='Vibrio harveyi', taxon_id=669, cell_types=[], best_structure='PDB:1JX6', other_structures=['PDB:1ZHH', 'PDB:2HJ9', 'PDB:4YR7', 'PDB:4YRZ', 'PDB:4YP9', 'AlphaFold:AF-P54300-F1'], go_terms=['GO:0042597 periplasmic space', 'GO:0003700 DNA-binding transcription factor activity', 'GO:0000976 transcription cis-regulatory region binding'], protein_diseases=[], method='assay', score=50000.0, source_ref='ChEMBL activity 2080832'),
    slot(uniprot_id='Q72547', protein_name='', protein_acronym='pol', species='Human immunodeficiency virus type 1', taxon_id=11676, cell_types=[], best_structure='PDB:3HYF', other_structures=['PDB:9UOA', 'PDB:2JLE'], go_terms=['GO:0004190 aspartic-type endopeptidase activity', 'GO:0042802 identical protein binding', 'GO:0046872 metal ion binding', 'GO:0003676 nucleic acid binding', 'GO:0003964 RNA-directed DNA polymerase activity'], protein_diseases=[], method='assay', score=100000.0, source_ref='ChEMBL activity 378337'),
    slot(uniprot_id='P16581', protein_name='E-selectin', protein_acronym='SELE', species='Homo sapiens', taxon_id=9606, cell_types=[], best_structure='PDB:1G1T', other_structures=['PDB:4C16', 'PDB:1ESL', 'PDB:6EYI', 'PDB:6EYJ', 'PDB:8R5L', 'PDB:9HGW', 'PDB:6EYK', 'PDB:9HGU', 'PDB:4CSY', 'PDB:9HGV', 'PDB:8R5M', 'PDB:9HGY', 'PDB:9HGX', 'AlphaFold:AF-P16581-F1'], go_terms=['GO:0005901 caveola', 'GO:0005905 clathrin-coated pit', 'GO:0030863 cortical cytoskeleton', 'GO:0009897 external side of plasma membrane', 'GO:0005576 extracellular region'], protein_diseases=[], method='assay', score=500000.0, source_ref='ChEMBL activity 1821915'),
    slot(uniprot_id='Q72874', protein_name='HIV-1 retropepsin', protein_acronym='pol', species='Human immunodeficiency virus type 1', taxon_id=11676, cell_types=[], best_structure='PDB:5V4Y', other_structures=[], go_terms=['GO:0004190 aspartic-type endopeptidase activity', 'GO:0006508 proteolysis'], protein_diseases=[], method='assay', score='', source_ref='ChEMBL activity 378338'),
    slot(uniprot_id='P12821', protein_name='Angiotensin-converting enzyme', protein_acronym='ACE', species='Homo sapiens', taxon_id=9606, cell_types=[], best_structure='PDB:6H5W', other_structures=['PDB:9H1E', 'PDB:7Q27', 'PDB:9QAN', 'PDB:9QAP', 'PDB:5AMB', 'PDB:6F9T', 'PDB:7Q25', 'PDB:7Q29', 'PDB:8QFX', 'PDB:5AMC', 'PDB:7Q28', 'PDB:6F9V', 'PDB:6TT3', 'PDB:7Q26', 'PDB:9H1B', 'PDB:6EN5', 'PDB:7Z6Z', 'PDB:4C2O', 'PDB:4UFA', 'PDB:4UFB', 'PDB:5AM9', 'PDB:5AMA', 'PDB:6EN6', 'PDB:6H5X', 'PDB:6QS1', 'PDB:6TT1', 'PDB:6TT4', 'PDB:9H1C', 'PDB:9H1D', 'PDB:1UZE', 'PDB:4BZR', 'PDB:4CA5', 'PDB:6F9R', 'PDB:6ZPQ', 'PDB:7Z70', 'PDB:9H1A', 'PDB:9QAM', 'PDB:5AM8', 'PDB:6F9U', 'PDB:8QHL', 'PDB:9GBM', 'PDB:9GBQ', 'PDB:9GBR', 'PDB:9GBS', 'PDB:9QAQ', 'PDB:9SSA', 'PDB:4CA6', 'PDB:9SS7', 'PDB:2XY9', 'PDB:3NXQ', 'PDB:4APH', 'PDB:4C2P', 'PDB:1O86', 'PDB:1O8A', 'PDB:1UZF', 'PDB:6ZPU', 'PDB:7Q24', 'PDB:9GBN', 'PDB:9GBO', 'PDB:9GBP', 'PDB:9QAU', 'PDB:9SS8', 'PDB:9SSB', 'PDB:2IUL', 'PDB:4BZS', 'PDB:2XYD', 'PDB:3BKK', 'PDB:3BKL', 'PDB:4BXK', 'PDB:9QAS', 'PDB:9QAT', 'PDB:2OC2', 'PDB:3L3N', 'PDB:4C2R', 'PDB:9QAO', 'PDB:9QAV', 'PDB:4C2Q', 'PDB:9GBL', 'PDB:2YDM', 'PDB:9SS9', 'PDB:4C2N', 'PDB:4APJ', 'PDB:2IUX', 'PDB:6ZPT', 'PDB:9D5S', 'PDB:2C6N', 'PDB:2C6F', 'PDB:9D5M', 'PDB:9D55', 'PDB:7Q4E', 'PDB:9CLX', 'PDB:7Q49', 'PDB:7Q4D', 'PDB:7Q4C', 'PDB:7Q3Y', 'PDB:9QAR', 'AlphaFold:AF-P12821-F1'], go_terms=['GO:0005737 cytoplasm', 'GO:0005768 endosome', 'GO:0009897 external side of plasma membrane', 'GO:0070062 extracellular exosome', 'GO:0005576 extracellular region'], protein_diseases=['ischemic stroke', 'renal tubular dysgenesis', 'microvascular complications of diabetes 3'], method='assay', score=7700000.0, source_ref='ChEMBL activity 2175820'),
]
