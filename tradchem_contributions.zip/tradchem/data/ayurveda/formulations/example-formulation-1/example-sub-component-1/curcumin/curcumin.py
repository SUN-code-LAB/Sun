﻿#!/usr/bin/env python3
"""
Trad-Chem-LLM submission record for Curcumin.
Canonical chemical definition and ranked target proteins.
"""
import sqlite3
import sys
from pathlib import Path

# import_data.py lives in <repo>/contributions/
sys.path.insert(0, str(Path(__file__).resolve().parents[7] / "contributions"))
try:
    from import_data import import_record, DB_DEFAULT
except ImportError:
    pass

# ------------------------------------------------------------------ the chemical
CHEMICAL = {'medicine': 'Example Medicine A', 'system': 'Ayurveda', 'plant': 'Curcuma longa', 'plant_type': 'herb', 'part_used': 'rhizome', 'family': 'Zingiberaceae', 'common_name': 'Turmeric', 'chemical_name': 'Curcumin', 'smiles': 'COc1cc(C=CC(=O)CC(=O)C=Cc2ccc(O)c(OC)c2)ccc1O', 'pubchem_cid': '2889', 'diseases': ['colorectal cancer']}


# ------------------------------------------------------------------ one protein slot
def slot(uniprot_id="", protein_name="", protein_acronym="", species="", taxon_id="",
         cell_types=(), best_structure="", other_structures=(), go_terms=(),
         protein_diseases=(), method="", score="", source_ref=""):
    """best_structure / other_structures look like  PDB:5IKR  |  AlphaFold:AF-P35354-F1  |  SWISS-MODEL:xxxx
    go_terms look like  "GO:0006954 inflammatory response"
    method: literature / SwissTargetPrediction / NetInfer / TrackMyPDB / docking / assay
    score: affinity or probability"""
    return dict(uniprot_id=uniprot_id, protein_name=protein_name, protein_acronym=protein_acronym,
                species=species, taxon_id=taxon_id, cell_types=list(cell_types),
                best_structure=best_structure, other_structures=list(other_structures),
                go_terms=list(go_terms), protein_diseases=list(protein_diseases),
                method=method, score=score, source_ref=source_ref)


# ------------------------------------------------------------------ top 10 proteins, best first
TARGETS = [
    slot(uniprot_id='P35354', protein_name='Prostaglandin G/H synthase 2', protein_acronym='PTGS2', species='Homo sapiens', taxon_id=9606, cell_types=['macrophage', 'epithelial cell'], best_structure='PDB:5IKR', other_structures=['AlphaFold:AF-P35354-F1'], go_terms=['GO:0006954 inflammatory response'], protein_diseases=['inflammation'], method='assay', score=15.0, source_ref='doi:10.1016/j.bmcl.2020.127500'),
]
